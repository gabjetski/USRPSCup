<?php
require_once 'vendor/autoload.php';
use Doctrine\DBAL\DriverManager;


$connectionParams = array(
    'url' => 'mysql://root:@localhost/usrps',
);
$conn = \Doctrine\DBAL\DriverManager::getConnection($connectionParams);
$queryBuilder = $conn->createQueryBuilder();

echo "<form action=" . $_SERVER['PHP_SELF'] . " method='get'>
<input placeholder='enter player1' name='p1'>
<br>
<input placeholder='enter player2' name='p2'>
<br>
<input placeholder='enter player1Sign' name='p1Sign'>
<br>
<input placeholder='enter player2Sign' name='p2Sign'>
<br>
<input placeholder='enter date' name='date'>
<br>
<input placeholder='enter time' name='time'>
<br>
<button type='submit' name='button' id='button'> new game </button>
</form>";


if (isset($_GET['button'])) {
    $queryBuilder
        ->insert('games')
        ->values(
            array(
                'player1' => "'" . $_GET['p1'] . "'",
                'player2' => "'" . $_GET['p2'] . "'",
                'player1Sign' => "'" . $_GET['p1Sign'] . "'",
                'player2Sign' => "'" . $_GET['p2Sign'] . "'",
                'd' => "'" . $_GET['date'] . "'",
                't' => "'" . $_GET['time'] . "'"
            )
        );
        $conn -> query($queryBuilder);
        header("Location:index.php");
}


?>
