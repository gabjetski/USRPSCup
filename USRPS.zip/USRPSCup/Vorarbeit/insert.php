<?php
require_once 'vendor/autoload.php';
use Doctrine\DBAL\DriverManager;


$connectionParams = array(
    'url' => 'mysql://root:@localhost/shirtdb',
);
$conn = \Doctrine\DBAL\DriverManager::getConnection($connectionParams);
$queryBuilder = $conn->createQueryBuilder();

echo "<form action=" . $_SERVER['PHP_SELF'] . " method='get'>
<input placeholder='enter id' name = 'id'>
<br>
<input placeholder='enter name' name='name'>
<br>
<input placeholder='enter size' name='size'>
<br>
<input placeholder='enter date' name='date'>
<br>
<button type='submit' name='button' id='button'> Neues Shirt </button>
</form>";


if (isset($_GET['button'])) {
    $queryBuilder
        ->insert('shirts')
        ->values(
            array(
                'id' => $_GET['id'],
                'name' => "'" . $_GET['name'] . "'",
                'size' =>  $_GET['size'] ,
                'published' => "'" . $_GET['date'] . "'"
            )
        );
        $conn -> query($queryBuilder);
}

?>
