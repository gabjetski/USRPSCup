<?php 
require_once 'vendor/autoload.php';
use Doctrine\DBAL\DriverManager;


$connectionParams = array(
    'url' => 'mysql://root:@localhost/shirtdb',
);
$conn = \Doctrine\DBAL\DriverManager::getConnection($connectionParams);
$queryBuilder = $conn->createQueryBuilder();

$sql = "SELECT * FROM shirts";
$stmt = $conn->query($sql);

echo "<form action=" . $_SERVER['PHP_SELF'] . " method='get'>";
while (($row = $stmt->fetchAssociative()) !== false) {
    echo $row['id'] . " - " . $row['name'] . " - " . $row['size'] . " - " . $row['published'] . "<button type='submit' name='" . $row['id'] . "'> DELETE </button> <br>";
    
    if(isset($_GET[$row['id']])){
        $conn->delete('shirts', array('id' => $row['id']));
        header("location:index.php");
    }
}
echo "</form>";
?>