<?php
namespace HTL3R\Rps;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="game")
 */
class Game
{
    
   /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     * @var int
     */
    protected $id;

    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $player1;

    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $player2;

    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $player1Sign;

    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $player2Sign;

    
    /**
     * @ORM\Column(type="datetime")
     * @var DateTime
     */
    protected $date;

    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $time;

    public function getId()
    {
        return $this->id;
    }

    public function getPlayer1()
    {
        return $this->player1;
    }
    
    public function getPlayer2()
    {
        return $this->player2;
    }
    
    public function getPlayer1Sign()
    {
        return $this->player1Sign;
    }
    
    public function getPlayer2Sign()
    {
        return $this->player2Sign;
    }

    public function getDate()
    {
        return $this->date;
    }

    public function getTime()
    {
        return $this->time;
    }

    public function setPlayer1($player1)
    {
        $this->player1 = $player1;
    }

    public function setPlayer2($player2)
    {
        $this->player2 = $player2;
    }

    public function setPlayer1Sign($player1Sign)
    {
        $this->player1Sign = $player1Sign;
    }

    public function setPlayer2Sign($player2Sign)
    {
        $this->player2Sign = $player2Sign;
    }

    public function setDate(\DateTime $date)
    {
        $this->date = $date;
    }

    public function setTime($time)
    {
        $this->time = $time;
    }
}
/*
$newgame = $entityManager->find('Game', 1);*/