<?php
namespace HTL3R\Rps;
require_once 'bootstrap.php';

// First Game
$game = new Game();
$game->setPlayer1('Gab');
$game->setPlayer2('Adam');
$game->setPlayer1Sign('Rock');
$game->setPlayer2Sign('Paper');
$game->setDate(new \DateTime("now"));
$game->setTime('11:01');
$entityManager->persist($game);

// Selecting Game 
$select = $entityManager->find('Game', 1);

// Updating Game
$gameUpdate = $entityManager->find('Game', 1);
$gameUpdate->setPlayer1('LESSGOO');

// Deleting Game
$entityManager->remove($game);

// Second Game
$game2 = new Game();
$game2->setPlayer1('Gab');
$game2->setPlayer2('Hannah Baker');
$game2->setPlayer1Sign('Rock');
$game2->setPlayer2Sign('Scissors');
$game2->setDate(new \DateTime("now"));
$game2->setTime('10:0');
$entityManager->persist($game2);
$entityManager->flush();