<?php 

require_once 'vendor/autoload.php';
use Doctrine\DBAL\DriverManager;

require_once 'inserts.php';


$connectionParams = array(
    'url' => 'mysql://root:@localhost/usrps',
);
$conn = \Doctrine\DBAL\DriverManager::getConnection($connectionParams);

$sql = "SELECT * FROM games";
$stmt = $conn->query($sql);


echo "<form action=" . $_SERVER['PHP_SELF'] . " method='get'>";
echo '<h1>USRPS Tournament</h1>';
while (($row = $stmt->fetchAssociative()) !== false) {
    echo '<h1> RPS Game ' . '</h1>
    <h2>' . $row['player1'] . ' vs ' . $row['player2'] . '</h2>
    <h2>' . $row['player1Sign'] . ' vs ' . $row['player2Sign'] . '</h2>
    <h2> Date ' . $row['d'] . '</h2>
    <h2> Time: ' . $row['t'] . '</h2>
    <button type="submit" name="' . $row['id'] . '"> DELETE </button>';

    if(isset($_GET[$row['id']])){
        $conn->delete('games', array('id' => $row['id']));
        header("location:index.php");
    }
}
echo "</form>";




?>