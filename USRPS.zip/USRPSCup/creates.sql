DROP DATABASE IF EXISTS usrps;
CREATE DATABASE usrps;
USE usrps;

create table games(
   id int not null AUTO_INCREMENT PRIMARY KEY,
   player1 varchar(50) not null,
   player2 varchar(50) not null,
   player1Sign varchar(50) not null,
   player2Sign varchar(50) not null,
   d DATE,
   t time
);

insert into games(player1, player2, player1Sign, player2Sign, d, t)
VALUES ('Hannah Baker', 'Gab', 'rock', 'paper', '2021-01-28', '10:00');

insert into games(player1, player2, player1Sign, player2Sign, d, t)
VALUES ('Bart Simpson', 'Adam', 'rock', 'scissors', '2021-01-28', '11:00');

insert into games(player1, player2, player1Sign, player2Sign, d, t)
VALUES ('Ted Mosby', 'Sasuke', 'Paper', 'Paper', '2021-03-24', '14:00');

insert into games(player1, player2, player1Sign, player2Sign, d, t)
VALUES ('Lebron James', 'Lil Baby', 'Rock', 'Scissors', '2021-12-12', '13:01');

insert into games(player1, player2, player1Sign, player2Sign, d, t)
VALUES ('Bill Gates', 'Yao Ming', 'Paper', 'Rock', '2021-01-29', '11:21');

